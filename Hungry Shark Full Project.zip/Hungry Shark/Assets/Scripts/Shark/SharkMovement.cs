using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))] 
public class SharkMovement : MonoBehaviour
{
    [SerializeField] private float _movementSpeed = 1f; // you can set your favourite movement speed in the inspector window
    [SerializeField] private GameObject _hintObject;
    private Rigidbody2D _rb;

    private Vector2 _moveDirection;

    private bool _playerMoved = false;
    private float _hintTimer = 2f;
    private float _idleTime = 0f;
    private bool _isfacingLeft = true; //default facing

    void Start()
    {
        _rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        ProcessInput();
        HintCountDown();
    }

    void FixedUpdate()
    {
        Move();
    }

    void ProcessInput()
    {
        float moveX = Input.GetAxisRaw("Horizontal");
        float moveY = Input.GetAxisRaw("Vertical");

        _moveDirection = new Vector2(moveX, moveY).normalized; //for consistency for diagonal movement
    }

    void Move()
    {
        Vector2 previousVelocity = _rb.velocity;
        Vector2 newVelocity = new Vector2(_moveDirection.x * _movementSpeed, _moveDirection.y * _movementSpeed);

        
        _isfacingLeft = newVelocity.x < 0f;

        if (newVelocity.x != 0f) // if player is moving
        {
            SetImageDirection(_isfacingLeft);
        }

        _playerMoved = previousVelocity != newVelocity;

        _rb.velocity = newVelocity;
    }

    void SetImageDirection(bool left)
    {
        var newScale = left ? new Vector2(Mathf.Abs(transform.localScale.x), transform.localScale.y) : new Vector2(-Mathf.Abs(transform.localScale.x), transform.localScale.y);
        transform.localScale = newScale;
    }

    void HintCountDown()
    {
        _idleTime = _playerMoved ? 0f : _idleTime + Time.deltaTime;

        SetHint(_idleTime >= _hintTimer);
    }
    
    

    void SetHint(bool show)
    {
        if (show)
        {
            if (!_hintObject.activeSelf)
            {
                _hintObject.gameObject.SetActive(true);
            }
        }

        if (!show)
        {
            if (_hintObject.activeSelf)
            {
                _hintObject.gameObject.SetActive(false);
            }
        }
    }
}
