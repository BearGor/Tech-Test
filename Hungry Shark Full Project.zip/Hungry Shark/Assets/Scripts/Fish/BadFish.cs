using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BadFish : MonoBehaviour,IEatable
{
    [SerializeField] private float _movementSpeed;

    private Rigidbody2D _rb;



    void Start()
    {
        _rb = GetComponent<Rigidbody2D>();
    }

    void OnSpawn()
    {

    }

    public void OnEaten()
    {
        GameController.Instance.ReducePlayerHealth();
        Destroy(gameObject);
    }

    void Move()
    {
        _rb.velocity = new Vector2(_movementSpeed, _rb.velocity.y);
    }

    void FixedUpdate()
    {
        Move();
    }

}
