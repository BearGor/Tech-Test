using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class GoodFish : MonoBehaviour, IEatable
{
    [SerializeField] private float _movementSpeed;
    [SerializeField] private int _score;

    private Rigidbody2D _rb;

    void Start()
    {
        _rb = GetComponent<Rigidbody2D>();
    }

    void OnSpawn()
    {

    }

  
    public void OnEaten()
    {
        GameController.Instance.AddScore(_score);
        Destroy(gameObject);
    }

    void Move()
    {
        _rb.velocity = new Vector2(_movementSpeed, _rb.velocity.y);
    }

    void FixedUpdate()
    {
        Move();
    }
}
