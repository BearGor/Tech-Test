
public interface IEatable
{
    void OnEaten();
}
