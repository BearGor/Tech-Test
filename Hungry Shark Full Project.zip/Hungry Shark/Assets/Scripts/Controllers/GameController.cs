using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour
{
    public static GameController Instance { get; private set; } // singleton

    [SerializeField] private float _spawnSpeed = 0.3f; // 0.3 sec per fish
    [SerializeField] private List<GameObject> _spawnPoints = new List<GameObject>();

    [SerializeField][Range(1,9)] private int _playerTotalHealth = 3;

    private int score = 0;
    private int playerCurrentHealth;

    private List<GameObject> playerHealth = new List<GameObject>();

    [SerializeField] private float _totalGameTime = 300f; // 5mins
    [Header("UI Elements")]
    [SerializeField] private TMP_Text _scoreText , _timeText , _finalScoreText;
    [SerializeField] private Transform _healthParent;
    [SerializeField] private GameObject _GameOverUI;
    [SerializeField] private Button btnReStart;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(this);
        }
        else
        {
            Instance = this;
        }
    }

    void Start()
    {
        Initialize();
    }

    private void Update()
    {
        _totalGameTime -= Time.deltaTime;
        UpdateTimeText();
        if (_totalGameTime <= 0f)
        {
            GameOver();
        }
    }

    void Initialize()
    {
        score = 0;
        Time.timeScale = 1f;
        foreach (var gameobject in playerHealth)
        {
            Destroy(gameobject);
        }
        playerHealth.Clear();

        for (int i = 0; i < _playerTotalHealth; i++)
        {
            var health = Instantiate(Resources.Load<GameObject>("Prefabs/health"));
            health.transform.SetParent(_healthParent);
            health.transform.localScale = Vector3.one;
            playerHealth.Add(health);
        }
        playerCurrentHealth = _playerTotalHealth;
        _scoreText.SetText("Score : " + score.ToString());
        btnReStart.onClick.AddListener(() => ReloadScene());
    }



    void GameOver()
    {
        Time.timeScale = 0f;
        _GameOverUI.SetActive(true);
        _finalScoreText.SetText(score.ToString());

    }

    public void ReducePlayerHealth()
    {
        playerCurrentHealth--;
        if (playerCurrentHealth <= 0)
        {
            GameOver();
        }

        for (int i = 0; i < playerHealth.Count; i++)
        {
            playerHealth[i].SetActive(i < playerCurrentHealth);
        }
    }

    public void AddScore(int amount)
    {
        score += amount;
        _scoreText.SetText("Score : " + score.ToString());
    }

    void UpdateTimeText()
    {
        int time = (int)_totalGameTime; // floor the time
        _timeText.SetText("Time : " + time.ToString());
    }

    void SpawnFish()
    {
        bool isGoodFish = Random.Range(0, 10) >= 5;

        string path = isGoodFish ? "Prefabs/Good Fish" : "Prefabs/Bad Fish";



    }

    void ReloadScene()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
